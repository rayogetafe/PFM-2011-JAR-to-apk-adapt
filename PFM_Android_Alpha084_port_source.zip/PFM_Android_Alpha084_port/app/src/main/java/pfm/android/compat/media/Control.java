package pfm.android.compat.media;
public interface Control {}
