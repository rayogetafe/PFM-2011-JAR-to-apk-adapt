package pfm.android.compat.lcdui;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public final class Graphics {
    public static final int HCENTER=1, VCENTER=2, LEFT=4, RIGHT=8, TOP=16, BOTTOM=32, BASELINE=64;
    private final Canvas canvas;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int tx, ty;
    private int rootSave;

    public Graphics(Bitmap target) {
        canvas = new Canvas(target);
        rootSave = canvas.save();
        paint.setTextSize(16f);
        paint.setColor(0xff000000);
    }

    public void setColor(int rgb) { paint.setColor(0xff000000 | (rgb & 0x00ffffff)); }
    public void fillRect(int x,int y,int w,int h) { canvas.drawRect(x,y,x+w,y+h,paint); }
    public void setFont(Font f) { if (f != null) { paint.setTextSize(f.paint.getTextSize()); paint.setTypeface(f.paint.getTypeface()); } }

    public void drawString(String s,int x,int y,int anchor) {
        if (s == null) s = "";
        float xx=x, yy=y;
        float width=paint.measureText(s);
        Paint.FontMetrics fm=paint.getFontMetrics();
        if ((anchor & HCENTER)!=0) xx-=width/2f; else if ((anchor & RIGHT)!=0) xx-=width;
        if ((anchor & BASELINE)!=0) { }
        else if ((anchor & BOTTOM)!=0) yy-=fm.bottom;
        else if ((anchor & VCENTER)!=0) yy-=(fm.ascent+fm.descent)/2f;
        else yy-=fm.ascent; // TOP/default: y is top, Canvas expects baseline.
        canvas.drawText(s,xx,yy,paint);
    }

    public void drawImage(Image img,int x,int y,int anchor) {
        if (img==null) return;
        float xx=x, yy=y; int w=img.getWidth(), h=img.getHeight();
        if ((anchor & HCENTER)!=0) xx-=w/2f; else if ((anchor & RIGHT)!=0) xx-=w;
        if ((anchor & VCENTER)!=0) yy-=h/2f; else if ((anchor & BOTTOM)!=0) yy-=h;
        canvas.drawBitmap(img.bitmap,xx,yy,null);
    }

    public void translate(int x,int y) { canvas.translate(x,y); tx+=x; ty+=y; }
    public int getTranslateX() { return tx; }
    public int getTranslateY() { return ty; }

    public void clipRect(int x,int y,int w,int h) { canvas.clipRect(x,y,x+w,y+h); }
    public void setClip(int x,int y,int w,int h) {
        try { canvas.restoreToCount(rootSave); } catch (Throwable ignored) {}
        rootSave = canvas.save();
        if (tx!=0 || ty!=0) canvas.translate(tx,ty);
        canvas.clipRect(x,y,x+w,y+h);
    }
}
