package pfm.android.compat.media.control;
import pfm.android.compat.media.Control;
public interface VolumeControl extends Control { int setLevel(int level); }
