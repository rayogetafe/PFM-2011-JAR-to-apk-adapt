package pfm.android.compat.rms;
public interface RecordFilter { boolean matches(byte[] candidate); }
