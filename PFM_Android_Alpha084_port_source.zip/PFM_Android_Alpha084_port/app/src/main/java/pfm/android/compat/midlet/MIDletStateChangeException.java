package pfm.android.compat.midlet;
public class MIDletStateChangeException extends Exception {
    public MIDletStateChangeException() { super(); }
    public MIDletStateChangeException(String message) { super(message); }
}
