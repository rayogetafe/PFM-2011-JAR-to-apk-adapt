package pfm.android.compat.lcdui.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import pfm.android.AndroidRuntime;
import pfm.android.compat.lcdui.Displayable;
import pfm.android.compat.lcdui.Graphics;

public class GameCanvas extends Displayable {
    public static final int UP=1, LEFT=2, RIGHT=5, DOWN=6, FIRE=8;
    private static final int LOGICAL_W = 360;
    private static final int LOGICAL_H = 503;
    private final Bitmap buffer = Bitmap.createBitmap(LOGICAL_W, LOGICAL_H, Bitmap.Config.ARGB_8888);
    private final GameView view;
    private volatile boolean shown;

    protected GameCanvas(boolean suppressKeyEvents) {
        view = new GameView();
        view.setFocusable(true);
        view.setFocusableInTouchMode(true);
    }

    public final View androidView() { return view; }
    public final void markShown(boolean v) { shown=v; }
    public final void showNotifyFromDisplay() { showNotify(); }
    public boolean isShown() { return shown; }
    public int getWidth() { return LOGICAL_W; }
    public int getHeight() { return LOGICAL_H; }
    public void setFullScreenMode(boolean full) {}
    public Graphics getGraphics() { return new Graphics(buffer); }
    public void flushGraphics() { AndroidRuntime.main().post(view::invalidate); }
    public void flushGraphics(int x,int y,int w,int h) { flushGraphics(); }
    public boolean hasPointerEvents() { return true; }
    public boolean hasPointerMotionEvents() { return true; }

    public int getKeyCode(int gameAction) {
        switch(gameAction) { case UP:return -1; case DOWN:return -2; case LEFT:return -3; case RIGHT:return -4; case FIRE:return -5; default:return gameAction; }
    }
    public int getGameAction(int keyCode) {
        switch(keyCode) {
            case -1: case '2': return UP;
            case -2: case '8': return DOWN;
            case -3: case '4': return LEFT;
            case -4: case '6': return RIGHT;
            case -5: case '5': return FIRE;
            default: return 0;
        }
    }
    protected void keyPressed(int keyCode) {}
    protected void keyReleased(int keyCode) {}
    protected void keyRepeated(int keyCode) {}
    protected void pointerPressed(int x,int y) {}
    protected void pointerReleased(int x,int y) {}
    protected void pointerDragged(int x,int y) {}

    private int legacyKey(int androidCode, KeyEvent e) {
        switch(androidCode) {
            case KeyEvent.KEYCODE_DPAD_UP:return -1; case KeyEvent.KEYCODE_DPAD_DOWN:return -2;
            case KeyEvent.KEYCODE_DPAD_LEFT:return -3; case KeyEvent.KEYCODE_DPAD_RIGHT:return -4;
            case KeyEvent.KEYCODE_DPAD_CENTER: case KeyEvent.KEYCODE_ENTER:return -5;
            case KeyEvent.KEYCODE_MENU:return -6; case KeyEvent.KEYCODE_BACK:return -7;
            default:
                int u=e.getUnicodeChar(); return u!=0 ? u : androidCode;
        }
    }

    private final class GameView extends View {
        GameView() { super(AndroidRuntime.activity()); setKeepScreenOn(true); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(0xff000000);
            Rect dst=fit(getWidth(),getHeight());
            c.drawBitmap(buffer,null,dst,null);
        }
        private Rect fit(int w,int h) {
            float s=Math.min(w/(float)LOGICAL_W,h/(float)LOGICAL_H);
            int dw=Math.round(LOGICAL_W*s), dh=Math.round(LOGICAL_H*s);
            int l=(w-dw)/2, t=(h-dh)/2; return new Rect(l,t,l+dw,t+dh);
        }
        private int lx(float x) { Rect r=fit(getWidth(),getHeight()); return Math.max(0,Math.min(LOGICAL_W-1,Math.round((x-r.left)*LOGICAL_W/(float)Math.max(1,r.width())))); }
        private int ly(float y) { Rect r=fit(getWidth(),getHeight()); return Math.max(0,Math.min(LOGICAL_H-1,Math.round((y-r.top)*LOGICAL_H/(float)Math.max(1,r.height())))); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int x=lx(e.getX()), y=ly(e.getY());
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: pointerPressed(x,y); return true;
                case MotionEvent.ACTION_MOVE: pointerDragged(x,y); return true;
                case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: pointerReleased(x,y); return true;
                default:return true;
            }
        }
        @Override public boolean onKeyDown(int code, KeyEvent e) {
            int k=legacyKey(code,e); if(e.getRepeatCount()>0) keyRepeated(k); else keyPressed(k); return true;
        }
        @Override public boolean onKeyUp(int code, KeyEvent e) { keyReleased(legacyKey(code,e)); return true; }
    }
}
