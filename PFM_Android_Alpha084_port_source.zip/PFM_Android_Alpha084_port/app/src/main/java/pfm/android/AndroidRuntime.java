package pfm.android;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class AndroidRuntime {
    private static volatile Activity activity;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Map<String,String> PROPERTIES;

    static {
        Map<String,String> p = new HashMap<>();
        p.put("MIDlet-Name", "PFM 2011 Career Lab");
        p.put("MIDlet-Version", "2.84.0");
        p.put("MIDlet-Vendor", "PFM Mod Lab");
        p.put("Glu-Demo-Enabled", "false");
        p.put("Glu-Upsell-Enabled", "false");
        p.put("GoalsHttpServiceUrl", "http://bravogames.goles.s3.amazonaws.com/goals3d.wml");
        PROPERTIES = Collections.unmodifiableMap(p);
    }

    private AndroidRuntime() {}
    public static void attach(Activity a) { activity = a; }
    public static Activity activity() {
        Activity a = activity;
        if (a == null) throw new IllegalStateException("Android Activity is not attached");
        return a;
    }
    public static Context context() { return activity().getApplicationContext(); }
    public static Handler main() { return MAIN; }
    public static String property(String key) { return PROPERTIES.get(key); }
}
