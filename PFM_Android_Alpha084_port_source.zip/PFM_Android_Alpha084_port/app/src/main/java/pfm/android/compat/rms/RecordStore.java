package pfm.android.compat.rms;

import java.io.*;
import java.util.*;
import pfm.android.AndroidRuntime;

public final class RecordStore {
    private static final int MAGIC=0x50465231; // PFR1
    private final String name;
    private final ArrayList<byte[]> records = new ArrayList<>();
    private boolean closed;

    private RecordStore(String name) { this.name=name; load(); }
    private static File dir() { File d=new File(AndroidRuntime.context().getFilesDir(),"rms"); if(!d.exists()) d.mkdirs(); return d; }
    private File file() { return new File(dir(), safe(name)+".rms"); }
    private static String safe(String s) { return s.replaceAll("[^A-Za-z0-9._-]","_"); }

    public static RecordStore openRecordStore(String name, boolean createIfNecessary) {
        File f=new File(dir(),safe(name)+".rms");
        if(!f.exists() && !createIfNecessary) throw new RuntimeException("RecordStore not found: "+name);
        return new RecordStore(name);
    }
    public static void deleteRecordStore(String name) {
        File f=new File(dir(),safe(name)+".rms"); if(f.exists() && !f.delete()) throw new RuntimeException("Cannot delete "+name);
    }
    public synchronized int getNumRecords() { ensure(); int n=0; for(byte[] b:records) if(b!=null)n++; return n; }
    public synchronized byte[] getRecord(int id) { ensure(); byte[] b=at(id); return Arrays.copyOf(b,b.length); }
    public synchronized int addRecord(byte[] data,int offset,int numBytes) { ensure(); records.add(Arrays.copyOfRange(data,offset,offset+numBytes)); save(); return records.size(); }
    public synchronized void setRecord(int id,byte[] data,int offset,int numBytes) { ensure(); while(records.size()<id)records.add(null); records.set(id-1,Arrays.copyOfRange(data,offset,offset+numBytes)); save(); }
    public synchronized RecordEnumeration enumerateRecords(RecordFilter filter, RecordComparator comparator, boolean keepUpdated) {
        ensure(); ArrayList<Integer> ids=new ArrayList<>();
        for(int i=0;i<records.size();i++){ byte[] r=records.get(i); if(r!=null && (filter==null||filter.matches(Arrays.copyOf(r,r.length)))) ids.add(i+1); }
        if(comparator!=null) ids.sort((a,b)->comparator.compare(records.get(a-1),records.get(b-1)));
        final int[] a=new int[ids.size()]; for(int i=0;i<a.length;i++)a[i]=ids.get(i);
        return new RecordEnumeration(){ int p; public boolean hasNextElement(){return p<a.length;} public int nextRecordId(){if(p>=a.length)throw new NoSuchElementException();return a[p++];} };
    }
    public synchronized void closeRecordStore(){ if(!closed){ save(); closed=true; } }
    private byte[] at(int id){ if(id<1||id>records.size()||records.get(id-1)==null)throw new RuntimeException("Bad record id "+id);return records.get(id-1); }
    private void ensure(){ if(closed)throw new IllegalStateException("RecordStore closed"); }
    private void load(){
        File f=file(); if(!f.exists())return;
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(f)))){
            if(in.readInt()!=MAGIC)throw new IOException("bad RMS magic"); int n=in.readInt();
            for(int i=0;i<n;i++){int len=in.readInt(); if(len<0)records.add(null);else{byte[] b=new byte[len];in.readFully(b);records.add(b);}}
        }catch(IOException e){throw new RuntimeException("Cannot load RMS "+name,e);}
    }
    private void save(){
        File f=file(), tmp=new File(f.getPath()+".tmp");
        try(DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))){
            out.writeInt(MAGIC); out.writeInt(records.size()); for(byte[] b:records){if(b==null)out.writeInt(-1);else{out.writeInt(b.length);out.write(b);}}
        }catch(IOException e){throw new RuntimeException("Cannot save RMS "+name,e);}
        if(f.exists()&&!f.delete())throw new RuntimeException("Cannot replace RMS "+name);
        if(!tmp.renameTo(f))throw new RuntimeException("Cannot commit RMS "+name);
    }
}
