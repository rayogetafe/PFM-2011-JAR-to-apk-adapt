package pfm.android.compat.lcdui;

import pfm.android.AndroidRuntime;
import pfm.android.compat.lcdui.game.GameCanvas;
import pfm.android.compat.midlet.MIDlet;

public final class Display {
    private static final Display INSTANCE = new Display();
    private volatile Displayable current;
    private Display() {}
    public static Display getDisplay(MIDlet ignored) { return INSTANCE; }
    public Displayable getCurrent() { return current; }

    public void setCurrent(Displayable next) {
        Displayable prev = current;
        if (next instanceof Alert) {
            current = next;
            ((Alert)next).show(() -> current = prev);
            return;
        }
        if (prev instanceof GameCanvas) ((GameCanvas)prev).markShown(false);
        if (prev != null) prev.hideNotify();
        current = next;
        AndroidRuntime.main().post(() -> {
            if (next instanceof GameCanvas) {
                GameCanvas gc = (GameCanvas) next;
                AndroidRuntime.activity().setContentView(gc.androidView());
                gc.markShown(true);
                gc.showNotifyFromDisplay();
            }
        });
    }
}
