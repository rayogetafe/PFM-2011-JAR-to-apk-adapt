package pfm.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import java.lang.reflect.Method;

public final class PfmActivity extends Activity {
    private Object gameMidlet;
    private Method startApp;
    private Method pauseApp;
    private boolean launched;
    private boolean paused;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        AndroidRuntime.attach(this);
        try {
            Class<?> c = Class.forName("midlet");
            gameMidlet = c.getDeclaredConstructor().newInstance();
            startApp = c.getDeclaredMethod("startApp");
            startApp.setAccessible(true);
            pauseApp = c.getDeclaredMethod("pauseApp");
            pauseApp.setAccessible(true);
            startApp.invoke(gameMidlet);
            launched = true;
        } catch (Throwable t) {
            throw new RuntimeException("Unable to start PFM Alpha 0.84 core", t);
        }
    }

    @Override protected void onPause() {
        if (launched && gameMidlet != null && pauseApp != null) {
            try { pauseApp.invoke(gameMidlet); } catch (Throwable ignored) {}
            paused = true;
        }
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        AndroidRuntime.attach(this);
        if (paused && launched && gameMidlet != null && startApp != null) {
            try { startApp.invoke(gameMidlet); } catch (Throwable ignored) {}
            paused = false;
        }
    }

    public void finishFromGame() { finish(); }
}
