package pfm.android.compat.rms;
public interface RecordEnumeration {
    boolean hasNextElement();
    int nextRecordId();
}
