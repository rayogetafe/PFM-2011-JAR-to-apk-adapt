package pfm.android.compat.media;

import android.media.MediaPlayer;
import java.io.*;
import pfm.android.AndroidRuntime;
import pfm.android.compat.media.control.VolumeControl;

public final class Manager {
    private Manager() {}
    public static Player createPlayer(InputStream stream,String type) throws IOException {
        File f=File.createTempFile("pfm_audio_", type!=null&&type.contains("amr")?".amr":".mid", AndroidRuntime.context().getCacheDir());
        try(FileOutputStream out=new FileOutputStream(f)) { byte[] b=new byte[8192]; for(int n;(n=stream.read(b))>0;)out.write(b,0,n); }
        return new AndroidPlayer(f);
    }
    private static final class AndroidPlayer implements Player, VolumeControl {
        private final MediaPlayer mp=new MediaPlayer(); private int state=UNREALIZED; private int loops=1;
        AndroidPlayer(File f) throws IOException { mp.setDataSource(f.getAbsolutePath()); }
        public void realize(){ if(state<REALIZED)state=REALIZED; }
        public void prefetch() throws IOException { if(state<PREFETCHED){ mp.prepare(); state=PREFETCHED; } }
        public void start() throws Exception { if(state<PREFETCHED)prefetch(); mp.setLooping(loops<0); mp.start(); state=STARTED; }
        public void stop(){ if(mp.isPlaying())mp.pause(); state=PREFETCHED; }
        public int getState(){ return state; }
        public Control getControl(String t){ return t!=null&&t.toLowerCase().contains("volume")?this:null; }
        public void setLoopCount(int c){ loops=c; }
        public long setMediaTime(long micros){ mp.seekTo((int)Math.max(0,Math.min(Integer.MAX_VALUE,micros/1000L))); return micros; }
        public int setLevel(int level){ int v=Math.max(0,Math.min(100,level)); float x=v/100f; mp.setVolume(x,x); return v; }
    }
}
