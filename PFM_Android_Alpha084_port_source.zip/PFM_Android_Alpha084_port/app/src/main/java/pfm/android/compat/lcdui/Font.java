package pfm.android.compat.lcdui;

import android.graphics.Paint;
import android.graphics.Typeface;

public final class Font {
    public static final int FACE_SYSTEM = 0;
    public static final int STYLE_PLAIN = 0;
    public static final int STYLE_BOLD = 1;
    public static final int STYLE_ITALIC = 2;
    public static final int SIZE_MEDIUM = 0;
    public static final int SIZE_SMALL = 8;
    public static final int SIZE_LARGE = 16;
    final Paint paint;

    private Font(int style, int size) {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float px = size == SIZE_SMALL ? 12f : (size == SIZE_LARGE ? 20f : 16f);
        paint.setTextSize(px);
        int tf = Typeface.NORMAL;
        if ((style & STYLE_BOLD) != 0 && (style & STYLE_ITALIC) != 0) tf = Typeface.BOLD_ITALIC;
        else if ((style & STYLE_BOLD) != 0) tf = Typeface.BOLD;
        else if ((style & STYLE_ITALIC) != 0) tf = Typeface.ITALIC;
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, tf));
    }
    public static Font getFont(int face, int style, int size) { return new Font(style, size); }
}
