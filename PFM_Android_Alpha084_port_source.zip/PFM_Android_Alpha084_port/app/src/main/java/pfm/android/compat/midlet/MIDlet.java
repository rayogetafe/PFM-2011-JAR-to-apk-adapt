package pfm.android.compat.midlet;

import android.content.Intent;
import android.net.Uri;
import pfm.android.AndroidRuntime;

public abstract class MIDlet {
    protected MIDlet() {}
    protected abstract void startApp() throws MIDletStateChangeException;
    protected abstract void pauseApp();
    protected abstract void destroyApp(boolean unconditional) throws MIDletStateChangeException;

    public final String getAppProperty(String key) { return AndroidRuntime.property(key); }

    public final boolean platformRequest(String url) {
        if (url == null || url.length() == 0) return false;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            AndroidRuntime.activity().startActivity(i);
            return true;
        } catch (Throwable ignored) { return false; }
    }

    public final void notifyDestroyed() {
        AndroidRuntime.main().post(() -> AndroidRuntime.activity().finish());
    }
    public final void notifyPaused() {}
    public final void resumeRequest() {}
}
