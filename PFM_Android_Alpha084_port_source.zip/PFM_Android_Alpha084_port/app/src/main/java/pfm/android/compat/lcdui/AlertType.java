package pfm.android.compat.lcdui;
public final class AlertType {
    public static final AlertType ERROR = new AlertType();
    private AlertType() {}
}
