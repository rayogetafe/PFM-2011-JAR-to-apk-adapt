package pfm.android.compat.lcdui;

import android.app.AlertDialog;
import pfm.android.AndroidRuntime;

public class Alert extends Displayable {
    public static final int FOREVER = -2;
    final String title;
    final String text;
    private int timeout = FOREVER;

    public Alert(String title, String alertText, Image alertImage, AlertType alertType) {
        this.title = title;
        this.text = alertText;
    }
    public void setTimeout(int time) { timeout = time; }
    void show(Runnable onDismiss) {
        AndroidRuntime.main().post(() -> {
            AlertDialog d = new AlertDialog.Builder(AndroidRuntime.activity())
                    .setTitle(title).setMessage(text).setPositiveButton(android.R.string.ok, null).create();
            d.setOnDismissListener(x -> { if (onDismiss != null) onDismiss.run(); });
            d.show();
            if (timeout > 0) AndroidRuntime.main().postDelayed(() -> { if (d.isShowing()) d.dismiss(); }, timeout);
        });
    }
}
