package pfm.android.compat.lcdui;
public class Displayable {
    protected void showNotify() {}
    protected void hideNotify() {}
    protected void sizeChanged(int w, int h) {}
}
