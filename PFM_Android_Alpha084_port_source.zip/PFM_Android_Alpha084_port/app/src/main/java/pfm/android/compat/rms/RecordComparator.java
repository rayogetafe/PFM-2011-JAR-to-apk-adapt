package pfm.android.compat.rms;
public interface RecordComparator {
    int PRECEDES=-1, EQUIVALENT=0, FOLLOWS=1;
    int compare(byte[] rec1, byte[] rec2);
}
