package pfm.android.compat.media;
public interface Player {
    int UNREALIZED=100, REALIZED=200, PREFETCHED=300, STARTED=400, CLOSED=0;
    void realize() throws Exception;
    void prefetch() throws Exception;
    void start() throws Exception;
    void stop() throws Exception;
    int getState();
    Control getControl(String controlType);
    void setLoopCount(int count);
    long setMediaTime(long now) throws Exception;
}
