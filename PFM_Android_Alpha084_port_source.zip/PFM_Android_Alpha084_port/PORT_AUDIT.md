# Alpha 0.84 Android-port audit

Source JAR: `pfm_2011_career_lab_iter2_alpha84.jar`

- Original game classes: 220
- Classes that referenced Java ME APIs: 49
- Patched core classes still referencing `javax.microedition.*`: 0
- External J2ME runtime bundled: none
- Internal Android adapter API: `pfm.android.compat.*`
- Android build output is not included because the generation environment had no Android SDK / D8 / AAPT2.

Platform surface that had to be replaced:

- lcdui: `Display`, `Displayable`, `Alert`, `AlertType`, `Font`, `Graphics`, `Image`, `GameCanvas`
- midlet: `MIDlet`, `MIDletStateChangeException`
- rms: `RecordStore`, `RecordEnumeration`, `RecordFilter`, `RecordComparator`
- media: `Manager`, `Player`, `Control`, `VolumeControl`

The game classes themselves no longer name `javax.microedition`. The Android adapter layer is source-owned by this project and uses Android `Activity`, `View`, `Canvas`, `Bitmap`, app-private files and `MediaPlayer`.
