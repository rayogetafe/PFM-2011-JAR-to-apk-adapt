#!/usr/bin/env python3
"""Rewrite Java ME platform references in PFM class constant pools to the internal Android port API."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import struct, sys

OLD_SLASH = b"javax/microedition"
NEW_SLASH = b"pfm/android/compat"
OLD_DOT = b"javax.microedition"
NEW_DOT = b"pfm.android.compat"

def patch_class(data: bytes) -> bytes:
    if data[:4] != b"\xCA\xFE\xBA\xBE":
        return data
    cp_count = struct.unpack_from(">H", data, 8)[0]
    out = bytearray(data[:10])
    off = 10
    i = 1
    while i < cp_count:
        tag = data[off]
        out.append(tag)
        off += 1
        if tag == 1:  # CONSTANT_Utf8
            ln = struct.unpack_from(">H", data, off)[0]
            off += 2
            raw = data[off:off+ln]
            off += ln
            raw = raw.replace(OLD_SLASH, NEW_SLASH).replace(OLD_DOT, NEW_DOT)
            out += struct.pack(">H", len(raw)) + raw
        elif tag in (3, 4):
            out += data[off:off+4]; off += 4
        elif tag in (5, 6):
            out += data[off:off+8]; off += 8; i += 1
        elif tag in (7, 8, 16, 19, 20):
            out += data[off:off+2]; off += 2
        elif tag in (9, 10, 11, 12, 17, 18):
            out += data[off:off+4]; off += 4
        elif tag == 15:
            out += data[off:off+3]; off += 3
        else:
            raise ValueError(f"Unsupported constant-pool tag {tag} at entry {i}")
        i += 1
    out += data[off:]
    return bytes(out)

def main(src: str, dst: str):
    with ZipFile(src, "r") as zin, ZipFile(dst, "w", ZIP_DEFLATED) as zout:
        for info in zin.infolist():
            if info.filename.endswith(".javap.txt"):
                continue
            raw = zin.read(info.filename)
            if info.filename.endswith(".class"):
                raw = patch_class(raw)
            # Old JAR signatures, if any, cannot remain valid after patching.
            upper = info.filename.upper()
            if upper.startswith("META-INF/") and upper.endswith((".SF", ".RSA", ".DSA")):
                continue
            zout.writestr(info, raw)
    blob = Path(dst).read_bytes()
    if OLD_SLASH in blob or OLD_DOT in blob:
        # ZIP compression can hide content, so inspect entries as well.
        with ZipFile(dst) as z:
            offenders = [n for n in z.namelist() if OLD_SLASH in z.read(n) or OLD_DOT in z.read(n)]
        if offenders:
            raise SystemExit("Unpatched Java ME references remain: " + ", ".join(offenders[:20]))

if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: patch_core.py input.jar output.jar")
    main(sys.argv[1], sys.argv[2])
