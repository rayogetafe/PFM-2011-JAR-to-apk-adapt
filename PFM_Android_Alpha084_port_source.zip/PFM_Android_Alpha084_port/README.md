# PFM 2011 Career Lab — Android port bootstrap (Alpha 0.84 core)

This project is generated from `pfm_2011_career_lab_iter2_alpha84.jar`.

## What is already ported structurally

- The original Alpha 0.84 game classes and resources are retained in `app/libs/pfm_core_android.jar`.
- All constant-pool references to `javax.microedition.*` in game classes are rewritten to the internal `pfm.android.compat.*` namespace.
- No external J2ME Loader dependency is used by this project.
- Android-native adapters are provided for the exact platform surfaces referenced by the current JAR: display/canvas, image/graphics/font, MIDlet lifecycle, RMS persistence, and media/volume.
- `PfmActivity` is the Android launcher and starts the existing `midlet` class directly.
- RMS data is stored privately under the Android app's files directory.

## Important status

This is a **port source tree**, not a claim that runtime parity is already validated. The source was prepared in an environment without Android SDK/D8/AAPT2, so an APK could not be compiled or device-smoke-tested in that environment.

The first Android build should be treated as `Android Port 0.1 / smoke-test`, with these checks before calling it parity-complete:

1. app starts to the same main menu;
2. New Career works for multiple clubs;
3. one match can be played and all screens render/touch correctly;
4. Save -> force-close -> Load preserves Alpha 0.84 P2 stores;
5. full season produces the same invariants, including global STARTS ALL;
6. sound failures, if any, do not affect gameplay;
7. compare one deterministic career run against JAR Alpha 0.84.

## Build

Use Android Studio, or push this tree to GitHub and run `.github/workflows/build-apk.yml`.

Expected debug output:

`app/build/outputs/apk/debug/app-debug.apk`

## Architecture choice

This is deliberately not an APK containing J2ME Loader. The old Java ME API symbols are removed from the PFM game classes and redirected to a small in-project Android implementation. That lets us preserve the already-patched gameplay core first, then replace legacy screens one by one with native Android UI without reimplementing match/economy/career logic at the same time.
